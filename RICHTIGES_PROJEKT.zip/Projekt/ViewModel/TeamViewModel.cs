﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using F1Tracker;

public class TeamViewModel : INotifyPropertyChanged
{
    private readonly ErgastApiService _ergastApiService = new ErgastApiService();
    private ObservableCollection<TeamBib> _teams;

    public ObservableCollection<TeamBib> Teams
    {
        get => _teams;
        set
        {
            _teams = value;
            OnPropertyChanged();
        }
    }

    public TeamViewModel()
    {
        LoadTeamsAsync();
    }

    public async Task LoadTeamsAsync()
    {
        var teamsData = await _ergastApiService.GetAllTeamsAsync();
        Teams = new ObservableCollection<TeamBib>(teamsData);
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}

﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using F1Tracker;

public class DriverViewModel : INotifyPropertyChanged
{
    //private readonly ErgastApiService _ergastApiService = new ErgastApiService();
    private ObservableCollection<DriverBib> _drivers = new ObservableCollection<DriverBib>();

    public ObservableCollection<DriverBib> Drivers
    {
        get => _drivers;
        set
        {
            _drivers = value;
            OnPropertyChanged();
        }
    }

    private List<string> _yearList;

    public List<string> YearList
    {
        get { return _yearList; }
        set 
        { 
            _yearList = value;
            OnPropertyChanged(); 
        }
    }




    public DriverViewModel()
    {
        YearList = new List<string>();
        for (int i = System.DateTime.Now.Year - 1; i >= 1990; i--)
        {
            YearList.Add(i.ToString());
        }
    }

    //public async Task LoadDriversAsync()
    //{
    //    var driversData = await _ergastApiService.GetAllDriversAsync(2023);
    //    Drivers = new ObservableCollection<DriverBib>(driversData);
    //}

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

}

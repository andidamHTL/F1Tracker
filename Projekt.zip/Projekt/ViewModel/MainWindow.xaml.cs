﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using F1Tracker;
using static System.Net.Mime.MediaTypeNames;

namespace ViewModel
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DriverViewModel _viewModel = null;

        public MainWindow()
        {
            InitializeComponent();
            confirmButton.Click += ConfirmButton_Click;
            yearChooser.SelectedIndex = 0;
            uiDriverList.SelectionChanged += UiDriverList_SelectionChanged;
        }

        private void UiDriverList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count == 0)
            {
                this.Dispatcher.Invoke(() =>
                {
                    driverImage.Source = null;
                });
                return; 
            }
                

            DriverBib driver = (DriverBib)e.AddedItems[0];

            this.Dispatcher.Invoke(() =>
            {
                DisplayDriverImage(driver.DriverId);
            });
        }

        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            int selectedYear = Convert.ToInt32(yearChooser.Text);
            Task.Run(() => DownloadData(selectedYear));
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);

            if (_viewModel == null)
            {
                Task.Run(() => DownloadData(DateTime.Now.Year - 1));
            }
        }

        private void DisplayDriverImage(string driverId)
        {
            BitmapImage b = new BitmapImage();
            b.BeginInit();
            b.UriSource = new Uri(System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), $@"img\{driverId}.jpg"));
            b.EndInit();
            driverImage.Source = b;
        }

        protected async void DownloadData(int year)
        {
            this.Dispatcher.Invoke(() =>
            {
                confirmButton.IsEnabled = false;
            });

            _viewModel = new DriverViewModel();

            ErgastApiService ergastApiService = new ErgastApiService();

            List<DriverBib> drivers = ergastApiService.GetAllDriversAsync(year).Result;
            
            foreach (DriverBib driver in drivers)
            {
                _viewModel.Drivers.Add(driver);
            }

            this.Dispatcher.Invoke(() =>
            {
                //uiDriverList.Items.Clear();
                uiDriverList.ItemsSource = _viewModel.Drivers;
                yearChooser.ItemsSource = _viewModel.YearList;
            });

            foreach (DriverBib driver in drivers)
            {
                driver.Team = ergastApiService.GetDriversTeamAsync(driver.DriverId, year).Result;
                this.Dispatcher.Invoke(() =>
                {
                    uiDriverListGrid.Columns[1].Width = uiDriverListGrid.Columns[1].ActualWidth;
                    uiDriverListGrid.Columns[1].Width = double.NaN;
                });
                driver.Points = ergastApiService.GetDriversPointsAsync(driver.DriverId, year).Result;
            }
            this.Dispatcher.Invoke(() =>
            {
                confirmButton.IsEnabled = true;
            });
        }
    }
}
